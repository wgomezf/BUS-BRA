function [perf,CM] = seg_cnn_predict(finalNet,imdsTest,pxdsTest,params,k)
    N    = numel(imdsTest{k}.Files); % Number of test images
    perf = zeros(N,4);      % Array to save performance results
    CM   = zeros(2,2,N);    % Array to save confusion matrices
    ID   = cell(N,1);       % Array to save image IDs
    dims = params.dims(params.folds.kFold==k,:); % Original image dimensions
    for j = 1:N % Each test image is segmented
        archI = imdsTest{k}.Files{j};       % Gray-level image   
        archL = pxdsTest{k}.Files{j};       % Mask image (Ground-truth)
        I = imread(archI);                  % Read gray-level image
        L = imread(archL);                  % Read binary mask
        S = semanticseg(I,finalNet,'ExecutionEnvironment','gpu'); % Tumor segmentation
        S = S==params.classes(2);           % Convert to binary mask
        [perf(j,:),CM(:,:,j)] = seg_performance(S,L);	% Evaluate segmentation performance
        S = cnn2im(S,dims(j,:));            % Resize segmented image to original dimensions
        % File name to save
        idx   = strfind(imdsTest{k}.Files{j},filesep);
        fname = imdsTest{k}.Files{j}(idx(end)+1:end);
        arch  = sprintf('%s_k%d%s',params.cnn,k,fname(4:end));
        ID{j} = fname(1:end-4);
        % Save segmented image
        imwrite(S,fullfile(params.segdir,arch),'png','Compression','none','BitDepth',1);
        clc; fprintf('Test data segmentation of fold %d: %0.3f%% \n',k,100*j/N);
    end
    % Save performance results
    save(fullfile(params.perdir,sprintf('perf_%s_k%d.mat',params.cnn,k)),'perf','CM','ID');
end
%******************************************************************
function S = cnn2im(S,sze)
    S = imresize(S,sze,'nearest'); % Ensures original size
end