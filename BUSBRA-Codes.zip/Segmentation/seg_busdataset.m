% Creates the resized BUS dataset for training a CNN for semantic
% segmentation.
function busdir = seg_busdataset(pathBUS,sze)
    % Create directories to save BUS data
    busdir = fullfile(pwd,'dataset');
    imgdir = fullfile(busdir,'Images');
    mskdir = fullfile(busdir,'Masks');
    if ~exist(busdir,'dir')
        mkdir(busdir);
        mkdir(imgdir);
        mkdir(mskdir);
    else
        fprintf('BUS dataset created\n');
        return
    end
    T   = readtable(fullfile(pathBUS,'bus_data.csv')); % Image IDs
    ID  = T.ID;
    N   = numel(ID);
    for i = 1:N % For each image in the BUS-BRA dataset
        % Read BUS image
        I = imread(fullfile(pathBUS,'Images',sprintf('%s.png',ID{i})));
        % Read binary mask (ground truth)
        B = imread(fullfile(pathBUS,'Masks',sprintf('mask%s.png',ID{i}(4:end))));
        [I,B] = gray2rgb(I,B,sze);  % Resize BUS image to cope CNN's input layer size
        % Save both resized images
        imwrite(I,fullfile(imgdir,sprintf('%s.png',ID{i})),'png','Compression','none','BitDepth',8);
        imwrite(B,fullfile(mskdir,sprintf('mask%s.png',ID{i}(4:end))),'png','Compression','none','BitDepth',1);
        clc; fprintf('Creating BUS dataset: %0.3f%%\n',100*i/N);
    end
end
%******************************************************************
function [J,B] = gray2rgb(I,B,sze)
    I = imresize(I,[sze sze],'bicubic');    % Resize gray-image
    I = stretching(I);                      % Intensity normalization
    J = cat(3,I,I,I);                       % Convert to RGB-style
    B = imresize(B,[sze sze],'nearest');    % Resize mask
end
%******************************************************************
function J = stretching(I)
    I = double(I);
    N = numel(I);
    h   = accumarray(I(:)+1,ones(N,1),[256 1],@sum,0);
    pdf = h/sum(h);
    cdf = cumsum(pdf);
    a = 255;
    b = 0;
    d = find(cdf>=0.05,1,'first');
    c = find(cdf>=0.95,1,'first');
    pix2 = round((I-c)*((a-b)/(c-d))+a);
    J = uint8(min(max(pix2,0),255));
end