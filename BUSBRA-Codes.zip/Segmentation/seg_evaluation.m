% This function performs the k-fold cross-validation method to evaluate the
% segmentation performance of the DeepLabV3+ model using ResNet18 or
% ResNet50 as back-bone networks for feature extraction.
%
% pathBUS: The directory that contains the original BUS-BRA dataset
% vld: A string with the type of validation: 'K5' is
%      5-fold cross-validation and 'K10' is 10-fold cross-validation.
% cnnopt: A string with type of CNN model: 'ResNet18' or 'ResNet50'

function seg_evaluation(pathBUS,vld,cnnopt)
    % Parameters
    params = seg_parameters(pathBUS,vld,cnnopt);
    % Training, validation, and test sets
    [imdsTrain,pxdsTrain,imdsValid,pxdsValid,imdsTest,pxdsTest] = seg_partitions(params);
    % Load DeepLabV3+ semantic segmentation model
    lgraph = seg_deeplab(params);
    % k-fold cross validation
    for k = 1:numel(imdsTrain)
        fprintf('BUS tumor segmentation - Training %s - Fold %d/%d\n',cnnopt,k,numel(imdsTrain));
        % Train CNN
        finalNet = seg_cnn_train(lgraph,imdsTrain,pxdsTrain,imdsValid,pxdsValid,params,k);
        % Segment test data
        seg_cnn_predict(finalNet,imdsTest,pxdsTest,params,k);
    end
end