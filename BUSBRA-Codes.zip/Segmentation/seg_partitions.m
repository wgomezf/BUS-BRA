function [imdsTrain,pxdsTrain,imdsValid,pxdsValid,imdsTest,pxdsTest] = seg_partitions(params)
    labelIDs = params.labelIDs; % Two classes
    K = params.K;   % Number of k-fold partitions
    classes = params.pxds.ClassNames;
    % Training set
    imdsTrain = cell(K,1);
    pxdsTrain = cell(K,1);
    % Validation set
    imdsValid = cell(K,1);
    pxdsValid = cell(K,1);
    % Test set
    imdsTest  = cell(K,1);
    pxdsTest  = cell(K,1);
    % Extract k-fold indices
    kf = params.folds.kFold;
    for k = 1:K
        % Extract test data
        testIdx     = kf==k; % Test indices
        testImages  = params.imds.Files(testIdx);  % BUS images
        testLabels  = params.pxds.Files(testIdx);  % Masks
        imdsTest{k} = imageDatastore(testImages);
        pxdsTest{k} = pixelLabelDatastore(testLabels,classes,labelIDs);
        % Training and validation indices
        trainIdx     = eval(sprintf('params.folds.valid_%d',k));
        % Extracts training data
        trainImages  = params.imds.Files(trainIdx==1);
        trainLabels  = params.pxds.Files(trainIdx==1);
        imdsTrain{k} = imageDatastore(trainImages);
        pxdsTrain{k} = pixelLabelDatastore(trainLabels,classes,labelIDs);
        % Extracts validation data
        validImages  = params.imds.Files(trainIdx==0);
        validLabels  = params.pxds.Files(trainIdx==0);
        imdsValid{k} = imageDatastore(validImages);
        pxdsValid{k} = pixelLabelDatastore(validLabels,classes,labelIDs);
    end
end