function [Out,CM] = seg_performance(Ypred,Ytrue)
    % Region-based indices
    Ypred = double(Ypred);
    Ytrue = double(Ytrue);
    Ypred = Ypred(:);
    Ytrue = Ytrue(:);
    pL = Ytrue == 1;
    nL = Ytrue == 0;
    TP  = sum(Ypred(pL)==1);      % True positives
    TN  = sum(Ypred(nL)==0);      % True negatives
    FP  = sum(Ypred(nL)==1);      % False positives
    FN  = sum(Ypred(pL)==0);      % False negatives
    F1s = (2*TP)/(2*TP+FP+FN);    % F1 score (Dice similarity)
    IoU = TP/(TP+FP+FN);          % Intersection over Union (Jaccard index)
    ACC = (TP+TN)/(TP+TN+FP+FN);  % Accuracy   
    CM  = [TP FN;FP TN];          % Confusion matrix
    % Edge-based index
    PD = propdist(Ytrue,Ypred);
    Out = [F1s IoU ACC PD];
    % Dice index (F1-score)
    % Intersection over Union (Jaccard index)
    % Accuracy (hit-rate)
    % Proportional distance between contours
end
%******************************************************************
% Proportional distance index
function PD = propdist(BW,E)
    S1 = bwperim(BW);
    S2 = bwperim(E);
    avdis1 = averagedist(S1,S2);
    avdis2 = averagedist(S2,S1);
    PD = ((avdis1 + avdis2)/(2*sqrt(bwarea(E)/pi)));
end
%******************************************************************
% Average distance between contours
function avdis = averagedist(cs,cr)
    [lseg,cseg] = find(cs);
    [lreal,creal] = find(cr);
    [Lseg,Lreal] = meshgrid(lseg,lreal);
    [Cseg,Creal] = meshgrid(cseg,creal);
    dist = sqrt((Lseg-Lreal).^2+(Cseg-Creal).^2);
    d = min(dist);
    avdis = mean(d);
end