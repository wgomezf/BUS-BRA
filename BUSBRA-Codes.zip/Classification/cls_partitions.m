function [imdsTrain,imdsValid,imdsTest] = cls_partitions(params)
    K = params.K;           % Number of k-fold partitions
    imdsTrain = cell(K,1);  % Training set
    imdsValid = cell(K,1);  % Validation set
    imdsTest  = cell(K,1);  % Test set
    % Extract k-fold indices
    kf = params.folds.kFold;
    X  = params.imds.Files;  % Images filenames
    Y  = params.imds.Labels; % Labels
    for k = 1:K
        testIdx = kf==k;       % Test indices
        imdsTest{k} = imageDatastore(X(testIdx),'Labels',Y(testIdx));
        trainIdx = eval(sprintf('params.folds.valid_%d',k));    % Training and validation indices
        imdsTrain{k} = imageDatastore(X(trainIdx==1),'Labels',Y(trainIdx==1));
        imdsValid{k} = imageDatastore(X(trainIdx==0),'Labels',Y(trainIdx==0));
    end
end