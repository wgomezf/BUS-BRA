function [Yp,Pr,perf,CM] = cls_cnn_predict(finalNet,imdsTest,params,k)
    N  = numel(imdsTest{k}.Files);  % Number of test images
    Yp = zeros(N,1);                % Array for predicted labels
    Pr = zeros(N,params.numClasses);% Array for posterior probabilities
    for j = 1:N
        I = imread(imdsTest{k}.Files{j}); % Read gray-level image
        [Yp(j),Pr(j,:)] = classify(finalNet,I); % Classify image with CNN
    end
    % Evaluate performance
    [perf,CM] = cls_binperf(imdsTest{k}.Labels,Yp,Pr,params);
    % Save performance results
    save(fullfile(params.perdir,sprintf('perf_%s_k%d.mat',params.cnn,k)),'perf','CM','Yp','Pr');
end