function [Out,C] = cls_binperf(Y,Yp,Sp,params)
    Yp = double(Yp)-1;
    Y  = double(Y)-1;
    labels = params.labelIDs;
    pL  = Y == labels(2);
    nL  = Y == labels(1);
    TP  = sum(Yp(pL)==labels(2));
    TN  = sum(Yp(nL)==labels(1));
    FP  = sum(Yp(nL)==labels(2));
    FN  = sum(Yp(pL)==labels(1));
    C   = [TP FN;FP TN]; % Confusion matrix
    ACC = (TP+TN)/(TP+TN+FP+FN); % Accuracy     
    MCC = ((TP*TN)-(FP*FN))/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN)); % Matthews correlation coefficient 
    PRE = TP/(TP+FP); % precision
    SEN = TP/(TP+FN); % sensitivity or recall
    SPE = TN/(FP+TN); % specificity
    BAC = 0.5*(SEN+SPE); % Precision
    F1s = (2*TP)/(2*TP+FP+FN); % F1 score
    Z   = AUC(Sp(:,2),Y,labels);
    Out = [ACC,MCC,PRE,SEN,SPE,F1s,BAC,Z];
end
%***********************************************************************
function z = AUC(Yp,Ytrue,labels)
    xi = Yp(Ytrue==labels(2));
    xj = Yp(Ytrue==labels(1));
    n0 = size(xi,1); 
    n1 = size(xj,1);
    [r,~] = tiedrank([xi;xj]);
    s0 = sum(r(1:n0));
    z = (s0-(n0*(n0+1)/2))/(n0*n1);
end