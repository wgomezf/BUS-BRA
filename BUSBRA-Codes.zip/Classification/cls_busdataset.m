function busdir = cls_busdataset(pathBUS,sze)
    busdir = fullfile(pwd,sprintf('dataset'));
    if ~exist(busdir,'dir')
        mkdir(busdir);
    else
        fprintf('BUS %dx%d px dataset created\n',sze,sze);
        return
    end
    T   = readtable(fullfile(pathBUS,'bus_data.csv')); % Read table of properties
    ID  = T.ID;     % Image ID
    N   = numel(ID);
    for i = 1:N
        % Read BUS image
        I = imread(fullfile(pathBUS,'Images',sprintf('%s.png',ID{i})));
        % Read binary mask (ground truth)
        B = imread(fullfile(pathBUS,'Masks',sprintf('mask%s.png',ID{i}(4:end))));
        % Crop ROI
        [I2,B2] = bbox(I,B);
        % Contrast stretching
        I2 = stretching(I2);
        % Adjust for CNN input layer size
        I2 = im2cnn(I2,sze);
        B2 = im2cnn(B2,sze);
        % Gray2RGB
        J = gray2rgb(I2,B2);
        % Save both resized images
        imwrite(J,fullfile(busdir,sprintf('%s.png',ID{i})),'png','Compression','none','BitDepth',8);
        clc; fprintf('Creating BUS dataset: %0.3f%%\n',100*i/N);
    end
end
%******************************************************************
function [I2,B2] = bbox(I,B)
    tol   = 10;
    [Y,X] = size(I);
    [y,x] = find(B);
    xmin  = max(min(x)-tol,1); xmax = min(max(x)+tol,X);
    ymin  = max(min(y)-tol,1); ymax = min(max(y)+tol,Y);
    B2    = B(ymin:ymax,xmin:xmax);
    I2    = I(ymin:ymax,xmin:xmax);
end
%******************************************************************
function J = stretching(I)
    I = double(I);
    N = numel(I);
    h   = accumarray(I(:)+1,ones(N,1),[256 1],@sum,0);
    pdf = h/sum(h);
    cdf = cumsum(pdf);
    a = 255;
    b = 0;
    d = find(cdf>=0.05,1,'first');
    c = find(cdf>=0.95,1,'first');
    pix2 = round((I-c)*((a-b)/(c-d))+a);
    J = uint8(min(max(pix2,0),255));
end
%******************************************************************
function I = im2cnn(I,sze)
    if islogical(I)
        pad = 0;
    else
        pad = 'circular';
    end
    [Ni,Mi] = size(I);
    t = round((max(Ni,Mi)-min(Ni,Mi))/2);
    if Ni < Mi
       I = padarray(I,[t 0],pad,'both');
    else
       I = padarray(I,[0 t],pad,'both'); 
    end
    I = imresize(I,[sze sze],'bicubic');
end
%******************************************************************
function J = gray2rgb(I0,B0)
    % https://doi.org/10.1016/j.cmpb.2021.106221
    % https://doi.org/10.1016/j.cmpb.2020.105361
    R = I0;
    G = I0; G(~B0) = 0;
    B = uint8(255*double(B0));
    J = cat(3,R,G,B);
end