function params = cls_parameters(pathBUS,vld,cnnopt)
    if not(strcmpi(vld,'K5')||strcmpi(vld,'K10'))
        error('Validation option must be K5 (5-fold) or K10 (10-fold)');
    end       
    if not(strcmpi(cnnopt,'resnet18')||strcmpi(cnnopt,'resnet50'))
        error('CNN architecture must be resnet18 or resnet50');
    end
    params.imsize = 224;           % ResNet input layer size
    params.path = cls_busdataset(pathBUS,params.imsize); % Directory to the BUS dataset
    params.cnn  = lower(cnnopt);   % CNN architecture
    params.maxepochs = 200;        % Number of epochs
    params.miniBatchSize = 32;     % Minibatch size
    params.LearningRate = 1e-4;    % Learning rate
    params.numClasses = 2;         % Two pathology classes
    params.labelIDs = [0 1];       % bening and malignant
    params.classes  = ["0";"1"];   % Class names
    % Data augmentation options
    params.augmenter = imageDataAugmenter('RandXReflection',true,...
                                          'RandYReflection',true,...
                                          'RandXTranslation',[-15 15],...
                                          'RandYTranslation',[-15 15],...
                                          'RandScale',[0.7 1.2],...
                                          'RandRotation',[-10 10]);
    % Data structures
    [params.imds,params.tbl] = ImageLabelDatastore(pathBUS,params);
    classWeights = 1./countcats(params.imds.Labels);
    params.classWeights = classWeights'/mean(classWeights);
    params.classImbalance = true;   % True for weighted cross entropy
    % Directories to save results
    resdir = fullfile(pwd,'results');
    cnndir = fullfile(resdir,'models');
    perdir = fullfile(resdir,'performance');
    if ~exist(resdir,'dir')
        mkdir(resdir);
        mkdir(cnndir);
        mkdir(perdir);
    end
    % Directory to save CNN models according to partition type
    if ~exist(fullfile(cnndir,upper(vld)),'dir')
        mkdir(fullfile(cnndir,upper(vld)));
    end
    params.cnndir = fullfile(cnndir,upper(vld));
    % Directory to save performance results according to partition type
    if ~exist(fullfile(perdir,upper(vld)),'dir')
        mkdir(fullfile(perdir,upper(vld)));
    end
    params.perdir = fullfile(perdir,upper(vld));
    % Data partitions
    params.K = str2double(vld(2:end));   % number of k-Fold partitions
    params.folds = readtable(fullfile(pathBUS,sprintf('%d-fold-cv.csv',params.K))); % Read table of k-fold partitions

end
%*********************************************************************
function [imds,tbl] = ImageLabelDatastore(pathbus,params)
    T  = readtable(fullfile(pathbus,'bus_data.csv'));
    if params.numClasses == 2
        Y = T.('Pathology'); % Pathology class labels
        Y = categorical(double(Y=="malignant"));
    elseif params.numClasses == 4
        Y = T.('BIRADS')-1; % BI-RADS class labels
        Y = categorical(Y);
    end
    imds = imageDatastore(params.path, 'LabelSource', 'none');
    imds.Labels = Y;
    tbl = countEachLabel(imds);
end