function lgraph = cls_cnn(params)
    net = eval(params.cnn);
    lgraph = layerGraph(net);
    FCLayer = fullyConnectedLayer(params.numClasses,'Name','new_fc','WeightLearnRateFactor',10,'BiasLearnRateFactor',10);
    if params.classImbalance
        outputLayer = classificationLayer('Name','output','Classes',params.classes,'ClassWeights',params.classWeights);
    else
        outputLayer = classificationLayer('Name','output');
    end
    lgraph = replaceLayer(lgraph,'fc1000',FCLayer);
    switch params.cnn
        case 'resnet18'
            lgraph = replaceLayer(lgraph,'ClassificationLayer_predictions',outputLayer);
        case 'resnet50'
            lgraph = replaceLayer(lgraph,'ClassificationLayer_fc1000',outputLayer);
    end
end