function [imdsTrain,pxdsTrain,imdsTest,pxdsTest] = seg_partitions(params)
    labelIDs = params.labelIDs; % Two classes
    kf = params.folds;
    % Create k-fold partitions
    K = max(kf);
    classes = params.pxds.ClassNames;
    if K == 2  
        K = 1; % Just a single hold-out partition
    end
    % Training set
    imdsTrain = cell(K,1);
    pxdsTrain = cell(K,1);
    % Test set
    imdsTest  = cell(K,1);
    pxdsTest  = cell(K,1);
    for k = 1:K
        testIdx  = kf==k;       % Test indices
        trainIdx = ~testIdx;    % Train indices
        % Extract filenames
        trainImages  = params.imds.Files(trainIdx);
        testImages   = params.imds.Files(testIdx);
        imdsTrain{k} = imageDatastore(trainImages);
        imdsTest{k}  = imageDatastore(testImages);
        % Extract labels
        trainLabels  = params.pxds.Files(trainIdx);
        testLabels   = params.pxds.Files(testIdx);
        pxdsTrain{k} = pixelLabelDatastore(trainLabels,classes,labelIDs);
        pxdsTest{k}  = pixelLabelDatastore(testLabels,classes,labelIDs);
    end
end