function lgraph = seg_deeplab(params)
    % Image size
    imageSize = [params.imsize params.imsize 3];
    % Load DeepLabV3+ semantic segmentation model with ResNet18 or ResNet50 backbone
    lgraph = deeplabv3plusLayers(imageSize, params.numClasses, params.cnn);
    % Adjust classification layer with Dice loss
    pxLayer = dicePixelClassificationLayer('Name','labels','Classes',params.tbl.Name);
    lgraph = replaceLayer(lgraph,"classification",pxLayer);
end