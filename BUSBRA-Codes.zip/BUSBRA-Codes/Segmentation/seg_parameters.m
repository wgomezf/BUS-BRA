function params = seg_parameters(pathBUS,vld,cnnopt)
    if not(strcmpi(vld,'HO')||strcmpi(vld,'K5')||strcmpi(vld,'K10'))
        error('Validation option must be HO (hold-out), K5 (5-fold), or K10 (10-fold)');
    end  
    if not(strcmpi(cnnopt,'resnet18')||strcmpi(cnnopt,'resnet50'))
        error('CNN architecture must be resnet18 or resnet50');
    end
    params.imsize = 224;           % ResNet models input layer size
    params.path = seg_busdataset(pathBUS,params.imsize); % Create resized BUS-BRA dataset
    params.valid = sprintf('%sP',upper(vld));   % Validation option with pathology class
    params.cnn = lower(cnnopt);    % CNN architecture
    params.maxepochs = 100;        % Number of epochs
    params.miniBatchSize = 32;     % Minibatch size
    params.LearningRate = 0.001;   % Learning rate
    params.numClasses = 2;         % Two classes
    params.labelIDs = [0 1];       % Background and Tumor classes
    params.classes  = ["normal";"tumor"];   % Class names
    % Data augmentation options
    params.augmenter = imageDataAugmenter('RandXReflection',true,...
                                          'RandYReflection',true,...
                                          'RandXTranslation',[-30 30],...
                                          'RandYTranslation',[-30 30],...
                                          'RandXScale',[0.5 1.5],...
                                          'RandYScale',[0.5 1.5],...
                                          'RandRotation',[-22.5 22.5]);
    % Data structures
    [params.imds,params.pxds,params.tbl] = ImageLabelDatastore(params);
    % Directories to save results
    resdir = fullfile(pwd,'results');
    cnndir = fullfile(resdir,'models');
    perdir = fullfile(resdir,'performance');
    segdir = fullfile(resdir,'segmentations');
    if ~exist(resdir,'dir')
        mkdir(resdir);
        mkdir(cnndir);
        mkdir(perdir);
        mkdir(segdir);
    end
    % Directory to save CNN models according to partition type
    if ~exist(fullfile(cnndir,upper(vld)),'dir')
        mkdir(fullfile(cnndir,upper(vld)));
    end
    params.cnndir = fullfile(cnndir,upper(vld));
    % Directory to save performance results according to partition type
    if ~exist(fullfile(perdir,upper(vld)),'dir')
        mkdir(fullfile(perdir,upper(vld)));
    end
    params.perdir = fullfile(perdir,upper(vld));
    % Directory to save segmented images according to partition type
    if ~exist(fullfile(segdir,upper(vld)),'dir')
        mkdir(fullfile(segdir,upper(vld)));
    end
    params.segdir = fullfile(segdir,upper(vld));
    T = readtable(fullfile(pathBUS,'bus_data.csv')); % Read table of properties
    params.dims = [T.Height T.Width];  % Original image sizes Rows x Columns
    params.folds = T.(params.valid);   % Training-test partitions
end
%*********************************************************************
function [imds,pxds,tbl] = ImageLabelDatastore(params)
    % Load BUS images
    imgDir = fullfile(params.path,'Images');
    imds   = imageDatastore(imgDir);
    % Load mask images
    labelDir = fullfile(params.path,'Masks');
    pxds = pixelLabelDatastore(labelDir,params.classes,params.labelIDs);
    % Count pixels
    tbl = countEachLabel(pxds);
end