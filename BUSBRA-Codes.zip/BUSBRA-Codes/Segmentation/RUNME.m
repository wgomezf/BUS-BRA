% Main function to run evaluations
clearvars; close all; clc;
if ~exist(fullfile('../BUSBRA'),'dir')
    fprintf('Please download the BUS-BRA dataset from Zenodo repository at\nhttps://doi.org/10.5281/zenodo.7730709\nand uncompress it in the root directory\n');
    return;
else
    pathBUS = fullfile('../BUSBRA');
end
cnns = {'resnet18' 'resnet50'};
for i = 1:numel(cnns)
    seg_evaluation(pathBUS,'K5',cnns{i});
end


