function [imdsTrain,imdsTest] = cls_partitions(params)
    kf = params.folds;
    % Create k-fold partitions
    K = max(kf);
    if K == 2  
        K = 1; % Just a single hold-out partition
    end
    imdsTrain = cell(K,1);  % Training set
    imdsTest  = cell(K,1);  % Test set
    X = params.imds.Files;  % Images filenames
    Y = params.imds.Labels; % Labels
    for k = 1:K
        testIdx  = kf==k;       % Test indices
        trainIdx = ~testIdx;    % Train indices
        % Extract filenames
        imdsTrain{k} = imageDatastore(X(trainIdx),'Labels',Y(trainIdx));
        imdsTest{k}  = imageDatastore(X(testIdx),'Labels',Y(testIdx));
    end
end