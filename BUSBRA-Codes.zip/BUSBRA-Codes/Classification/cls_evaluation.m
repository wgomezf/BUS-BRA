% This function performs the k-fold cross-validation method to evaluate the
% classification performance of the ResNet18 or ResNet50 networks for 
% classifying pathology classes or BI-RADS categories
%
% pathBUS: The directory that contains the original BUS-BRA dataset
% vld: A string with the type of validation: 'HO' is hold-out, 'K5' is
%      5-fold cross-validation, and 'K10' is 10-fold cross-validation.
% lbl: A string with class label option: 'P' for pathology classes bening
%      and malignant, and 'B' for BI-RADS categories 2, 3, 4, and 5.
% cnnopt: A string with type of CNN model: 'ResNet18' or 'ResNet50'

function cls_evaluation(pathBUS,vld,lbl,cnnopt)
    % Parameters
    params = cls_parameters(pathBUS,vld,lbl,cnnopt);
    % Training and test sets
    [imdsTrain,imdsTest] = cls_partitions(params);
    % Load CNN model
    lgraph = cls_cnn(params);
    % k-fold cross validation
    for k = 1:numel(imdsTrain)
        fprintf('BUS classification in %s classes - Training %s - Fold %d/%d\n',params.ctype,cnnopt,k,numel(imdsTrain));
        % Train CNN
        finalNet = cls_cnn_train(lgraph,imdsTrain,params,k);
        % Predict CNN
        cls_cnn_predict(finalNet,imdsTest,params,k);
    end
end