function params = cls_parameters(pathBUS,vld,lbl,cnnopt)
    if not(strcmpi(vld,'HO')||strcmpi(vld,'K5')||strcmpi(vld,'K10'))
        error('Validation option must be HO (hold-out), K5 (5-fold), or K10 (10-fold)');
    end      
    if not(strcmpi(lbl,'B')||strcmpi(lbl,'P'))
        error('Class label option must be P (pathology) or B (BI-RADS)');
    end    
    if not(strcmpi(cnnopt,'resnet18')||strcmpi(cnnopt,'resnet50'))
        error('CNN architecture must be resnet18 or resnet50');
    end
    params.imsize = 224;           % ResNet input layer size
    params.path = cls_busdataset(pathBUS,params.imsize); % Directory to the BUS dataset
    params.cnn  = lower(cnnopt);   % CNN architecture
    params.maxepochs = 100;        % Number of epochs
    params.miniBatchSize = 32;     % Minibatch size
    params.LearningRate = 1e-4;    % Learning rate
    if strcmpi(lbl,'B')     % BI-RADS classes
        params.numClasses = 4;         % Four BI-RADS classes
        params.labelIDs = [1 2 3 4];   % 2 to 5
        params.classes  = ["1";"2";"3";"4"];   % Class names
        params.ctype = 'BI-RADS';
    elseif strcmpi(lbl,'P') % Pathology classes
        params.numClasses = 2;     % Two pathology classes
        params.labelIDs = [0 1];   % bening and malignant
        params.classes  = ["0";"1"];   % Class names
        params.ctype = 'pathology';
    end
    % Data augmentation options
    params.augmenter = imageDataAugmenter('RandXReflection',true,...
                                          'RandYReflection',true,...
                                          'RandXTranslation',[-15 15],...
                                          'RandYTranslation',[-15 15],...
                                          'RandScale',[0.7 1.2],...
                                          'RandRotation',[-10 10]);
    % Data structures
    [params.imds,params.tbl] = ImageLabelDatastore(pathBUS,params);
    classWeights = 1./countcats(params.imds.Labels);
    params.classWeights = classWeights'/mean(classWeights);
    params.classImbalance = true;   % True for weighted cross entropy
    % Directories to save results
    resdir = fullfile(pwd,'results');
    cnndir = fullfile(resdir,'models');
    perdir = fullfile(resdir,'performance');
    if ~exist(resdir,'dir')
        mkdir(resdir);
        mkdir(cnndir);
        mkdir(perdir);
    end
    % Directory to save CNN models according to partition type
    if ~exist(fullfile(cnndir,upper(vld)),'dir')
        mkdir(fullfile(cnndir,upper(vld)));
    end
    % Directory to save CNN models according to partition type and label type
    if ~exist(fullfile(cnndir,upper(vld),upper(lbl)),'dir')
        mkdir(fullfile(cnndir,upper(vld),upper(lbl)));
    end
    params.cnndir = fullfile(cnndir,upper(vld),upper(lbl));
    % Directory to save performance results according to partition type
    if ~exist(fullfile(perdir,upper(vld)),'dir')
        mkdir(fullfile(perdir,upper(vld)));
    end
    % Directory to save performance results according to partition type and label type
    if ~exist(fullfile(perdir,upper(vld),upper(lbl)),'dir')
        mkdir(fullfile(perdir,upper(vld),upper(lbl)));
    end
    params.perdir = fullfile(perdir,upper(vld),upper(lbl));
    % Data partitions
    T = readtable(fullfile(pathBUS,'bus_data.csv')); % Read table of properties
    params.valid = sprintf('%s%s',upper(vld),upper(lbl));
    params.folds = T.(params.valid);   % Training-test partitions
end
%*********************************************************************
function [imds,tbl] = ImageLabelDatastore(pathbus,params)
    T  = readtable(fullfile(pathbus,'bus_data.csv'));
    if params.numClasses == 2
        Y = T.('Pathology'); % Pathology class labels
        Y = categorical(double(Y=="malignant"));
    elseif params.numClasses == 4
        Y = T.('BIRADS')-1; % BI-RADS class labels
        Y = categorical(Y);
    end
    imds = imageDatastore(params.path, 'LabelSource', 'none');
    imds.Labels = Y;
    tbl = countEachLabel(imds);
end