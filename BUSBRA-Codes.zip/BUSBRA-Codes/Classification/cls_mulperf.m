function [Out,C] = cls_mulperf(Y,Yp,Sp,params)
    Yp = double(Yp);
    Y  = double(Y);
    nc = params.numClasses;
    % Confusion matrix
    C = zeros(nc);
    for i = 1:nc
        for j = 1:nc
            C(j,i) = sum((Y==i)&(Yp==j));
        end
    end
    n  = sum(C(:));     % Number of samples
    tp = zeros(1,nc);   % True positives
    tn = zeros(1,nc);   % True negatives
    fp = zeros(1,nc);   % False negatives
    fn = zeros(1,nc);   % False positives
    for i = 1:nc
        tp(i) = C(i,i);
        fp(i) = sum(C(i,:))-C(i,i);
        fn(i) = sum(C(:,i))-C(i,i);
        tn(i) = n-(tp(i)+fp(i)+fn(i));
    end
    % Indices
    ACG = sum(tp)/n;                      % Global accuracy
    PRE = sum(tp./(tp+fp))/nc;            % Precision
    SEN = sum(tp./(tp+fn))/nc;            % Sensitivity 
    SPE = sum(tn./(tn+fp))/nc;            % Specificiy
    F1s = (2*PRE*SEN)/(PRE+SEN);          % F1 score
    BAC = 0.5*(SEN+SPE);                  % Balanced accuracy
    % Multiclass MCC
    Skl_num  = 0;
    Skl_den1 = 0;
    Skl_den2 = 0;
    Ct  = C';
    for k = 1:nc
        for l = 1:nc
            Skl_num  = Skl_num  + sum(C(k,:).*(C(:,l)'));
            Skl_den1 = Skl_den1 + sum(C(k,:).*(Ct(:,l)'));
            Skl_den2 = Skl_den2 + sum(Ct(k,:).*(C(:,l)'));
        end
    end
    MCC = (n*trace(C) - Skl_num)/(sqrt(n*n - Skl_den1)*sqrt(n*n - Skl_den2));
    Z = AUC(Sp,Y,nc);
    Out = [ACG,MCC,PRE,SEN,SPE,F1s,BAC,Z];
end
%***********************************************************************
function z = AUC(Sp,Ytrue,nc)
    z = zeros(1,nc);
    for i = 1:nc
        xi = Sp(Ytrue==i,i);
        xj = Sp(not(Ytrue==i),i);
        n0 = size(xi,1); 
        n1 = size(xj,1);
        [r,~] = tiedrank([xi;xj]);
        s0 = sum(r(1:n0));
        z(i) = (s0-(n0*(n0+1)/2))/(n0*n1);
    end
    z = mean(z);
end